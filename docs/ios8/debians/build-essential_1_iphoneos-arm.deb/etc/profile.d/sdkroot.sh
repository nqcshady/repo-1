export SDKROOT=$(ls -d /usr/share/SDKs/iPhoneOS*.sdk | head -n1)
